const unfinishedList = document.getElementById("unfinished-list");
const finishedList = document.getElementById("finished-list");
const addBookForm = document.getElementById("add-book-form");
const searchInput = document.getElementById("search");
const searchButton = document.getElementById("search-button");

function renderBook(book) {
  const listItem = document.createElement("li");
  listItem.innerHTML = `
    <span>${book.title} - ${book.author} (${book.year})</span>
    <button class="move-btn">${
      book.isComplete ? "Pindahkan ke Belum Selesai" : "Pindahkan ke Selesai"
    }</button>
    <button class="edit-btn">Edit</button>
    <button class="delete-btn">Hapus</button>
  `;
  const moveButton = listItem.querySelector(".move-btn");
  const editButton = listItem.querySelector(".edit-btn");
  const deleteButton = listItem.querySelector(".delete-btn");

  moveButton.addEventListener("click", function () {
    book.isComplete = !book.isComplete;
    renderBooks();
  });

  editButton.addEventListener("click", function () {
    editBook(book);
  });

  deleteButton.addEventListener("click", function () {
    const index = books.findIndex((b) => b.id === book.id);
    books.splice(index, 1);
    renderBooks();
  });

  if (book.isComplete) {
    finishedList.appendChild(listItem);
  } else {
    unfinishedList.appendChild(listItem);
  }
}

function renderBooks() {
  unfinishedList.innerHTML = "";
  finishedList.innerHTML = "";
  books.forEach((book) => renderBook(book));
  localStorage.setItem("books", JSON.stringify(books));
}

function addBook(event) {
  event.preventDefault();

  const titleInput = document.getElementById("title");
  const authorInput = document.getElementById("author");
  const yearInput = document.getElementById("year");
  const isCompleteCheckbox = document.getElementById("is-complete");

  const newBook = {
    id: +new Date(),
    title: titleInput.value,
    author: authorInput.value,
    year: parseInt(yearInput.value),
    isComplete: isCompleteCheckbox.checked,
  };

  books.push(newBook);
  renderBooks();

  titleInput.value = "";
  authorInput.value = "";
  yearInput.value = "";
  isCompleteCheckbox.checked = false;
}

function searchBooks() {
  const searchTerm = searchInput.value.toLowerCase();
  const filteredBooks = books.filter((book) =>
    book.title.toLowerCase().includes(searchTerm)
  );

  unfinishedList.innerHTML = "";
  finishedList.innerHTML = "";
  filteredBooks.forEach((book) => renderBook(book));
}

function editBook(book) {
  const newTitle = prompt("Edit judul buku:", book.title);
  const newAuthor = prompt("Edit penulis buku:", book.author);
  const newYear = prompt("Edit tahun terbit buku:", book.year);

  if (newTitle !== null && newAuthor !== null && newYear !== null) {
    book.title = newTitle.trim();
    book.author = newAuthor.trim();
    book.year = parseInt(newYear.trim());

    renderBooks();
  }
}

addBookForm.addEventListener("submit", addBook);
searchButton.addEventListener("click", searchBooks);

let books = JSON.parse(localStorage.getItem("books")) || [];

renderBooks();
